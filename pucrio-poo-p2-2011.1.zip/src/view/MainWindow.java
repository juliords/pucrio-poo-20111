
package view;

import graph.GraphModel;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.io.FileNotFoundException;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 * @author Julio Ribeiro
 * @author Luís Henrique Pelosi
 * @author Peter Brasil
 */
public class MainWindow extends JFrame
{

    private static MainWindow mw = null;

    public static MainWindow getUniqueInstance()
    {
        if (mw == null)
        {
            mw = new MainWindow();
        }
        return mw;
    }
    private GraphModel model;
    private JDesktopPane desk;

    private MainWindow()
    {
        this.model = new GraphModel();
        this.setSize(600, 600);

        JMenuBar menuBar = new JMenuBar();
        JMenu filemenu = new JMenu("File");
        JMenu viewmenu = new JMenu("View");

        menuBar.add(filemenu);
        menuBar.add(viewmenu);

        JMenuItem quititem = new JMenuItem("Quit");
        quititem.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });

        JMenuItem loaditem = new JMenuItem("Load");
        loaditem.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                JFileChooser file = new JFileChooser();

                int result = file.showOpenDialog(MainWindow.getUniqueInstance());

                if (result == JFileChooser.APPROVE_OPTION)
                {
                    String filePath = file.getSelectedFile().getPath();
                    String fileName = file.getSelectedFile().getName();

                    try
                    {
                        model.load(filePath, fileName);
                    } catch (FileNotFoundException ex)
                    {
                        JOptionPane.showMessageDialog(MainWindow.getUniqueInstance(), "Arquivo não encontrado.");
                    } catch (Exception ex)
                    {
                        JOptionPane.showMessageDialog(MainWindow.getUniqueInstance(), "Erro ao carregar arquivo.");
                    }
                }
            }
        });

        JMenuItem saveitem = new JMenuItem("Save");
        saveitem.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(MainWindow.getUniqueInstance(), "A função de salvamento de grafo ainda não foi implementada.");
            }
        });
        JMenuItem newitem = new JMenuItem("New");
        newitem.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(MainWindow.getUniqueInstance(), "A função de carregamento de grafo ainda não foi implementada.");
            }
        });

        JMenuItem newviewitem = new JMenuItem("New");
        newviewitem.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                GraphView graphview = new GraphView("Graph View");
                desk.add(graphview);
                resizeInternalFrames(e);
            }
        });

        JMenuItem reorderitem = new JMenuItem("Organize");
        reorderitem.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                resizeInternalFrames(e);
            }
        });

        filemenu.add(newitem);
        filemenu.add(loaditem);
        filemenu.add(saveitem);
        filemenu.add(quititem);
        viewmenu.add(newviewitem);
        viewmenu.add(reorderitem);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.setJMenuBar(menuBar); //set the Frames JMenuBar
        this.setTitle("Graph Viewer"); //title of the frame
        this.setVisible(true); //show the Frame

        desk = new JDesktopPane();
        desk.setAutoscrolls(true);
        desk.setDoubleBuffered(true);
        desk.setVisible(true);
        setContentPane(desk);
    }

    public void resizeInternalFrames(ActionEvent ev)
    {

        // Quantos frames?
        JInternalFrame[] allframes = desk.getAllFrames();
        int count = allframes.length;
        if (count == 0)
        {
            return;
        }

        // Define tamanho do grid
        int sqrt = (int) Math.sqrt(count);
        int rows = sqrt;
        int cols = sqrt;
        if (rows * cols < count)
        {
            cols++;
            if (rows * cols < count)
            {
                rows++;
            }
        }

        Dimension size = desk.getSize();

        int w = size.width / cols;
        int h = size.height / rows;
        int x = 0;
        int y = 0;

        // Itera sobre os frames, realocando e fazendo resize de cada
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols && ((i * cols) + j < count); j++)
            {
                JInternalFrame f = allframes[(i * cols) + j];

                if (!f.isClosed() && f.isIcon())
                {
                    try
                    {
                        f.setIcon(false);
                    } catch (PropertyVetoException ignored)
                    {
                    }
                }

                desk.getDesktopManager().resizeFrame(f, x, y, w, h);
                x += w;
            }
            y += h; // próxima linha
            x = 0;
        }
    }

    public GraphModel getGraphModel()
    {
        return this.model;
    }
}
