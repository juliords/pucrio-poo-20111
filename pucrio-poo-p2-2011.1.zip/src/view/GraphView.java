

package view;

import graph.GraphModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;

/**
 * @author Julio Ribeiro
 * @author Luís Henrique Pelosi
 * @author Peter Brasil
 */
public class GraphView extends JInternalFrame
{

    private JPanel checkPanel = new JPanel(new GridLayout(0, 1));
    private ViewCanvas canvas;

    public GraphView(String nome)
    {
        super();
        this.setVisible(true);
        this.setResizable(true);
        this.setClosable(true);
        this.setDoubleBuffered(true);
        this.setMaximizable(true);
        this.setTitle(nome);
        this.setAutoscrolls(true);
        this.setBackground(Color.WHITE);

        canvas = new ViewCanvas();
        this.getContentPane().add(canvas);

        checkPanel = new JPanel(new GridLayout(0, 1));
        checkPanel.setAutoscrolls(true);
        checkPanel.setVisible(true);
        add(checkPanel, BorderLayout.EAST);

        final GraphModel gm = MainWindow.getUniqueInstance().getGraphModel();
        gm.addListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                addcheckbox(gm.getLastIndex());
                canvas.addGraph(gm.getLastIndex());
                canvas.setVisible(gm.getLastIndex(), true);
            }
        });

        for (String name : gm.getGraphNames())
        {
            addcheckbox(name);
            canvas.addGraph(name);
            canvas.setVisible(name, true);
        }
    }

    private void addcheckbox(final String nome)
    {
        JCheckBox chk = new JCheckBox(nome);
        chk.setSelected(true);

        chk.addItemListener(new ItemListener()
        {

            public void itemStateChanged(ItemEvent e)
            {
                canvas.setVisible(nome, e.getStateChange() == ItemEvent.SELECTED);
                canvas.repaint();
            }
        });
        checkPanel.add(chk);
        checkPanel.revalidate();
    }
}
