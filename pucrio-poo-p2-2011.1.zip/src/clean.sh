rm ./graph/*.class
rm ./graph/exception/*.class
rm ./pucriopoo20111/*.class
rm ./view/*.class
