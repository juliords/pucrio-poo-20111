package graph.exception;

public class MissingVertice extends VerticeException
{
    @Override
    public String toString() { return "Vertice nao encontrado no grafo";}
}
