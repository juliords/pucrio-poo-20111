/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graph.exception;

/**
 *
 * @author juliords
 */
public class CannotCreateFile extends GraphException
{
    @Override
    public String toString() { return "Problema ao criar arquivo para salvar grafo.";}
}
