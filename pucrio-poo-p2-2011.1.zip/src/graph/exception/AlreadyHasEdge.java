package graph.exception;

public class AlreadyHasEdge extends EdgeException
{
    @Override
    public String toString() { return "Aresta ja contida no grafo";}
}
