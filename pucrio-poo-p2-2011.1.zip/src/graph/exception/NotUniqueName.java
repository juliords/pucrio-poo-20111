package graph.exception;

public class NotUniqueName extends VerticeException
{
    @Override
    public String toString() { return "O nome nao eh univoco";}
}
