package graph.exception;

public class AlreadyHasVertice extends VerticeException
{
    @Override
    public String toString() { return "Vertice ja contido no grafo";}
}
