
package graph;

import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/**
 * @author Julio Ribeiro
 * @author Luís Henrique Pelosi
 * @author Peter Brasil
 */
public class GraphModel
{

    public final static String SUFFIX = ".grf";
    private HashMap<String, Graph> graphList = new HashMap<String, Graph>();
    private String lastName = null;
    private ArrayList<ActionListener> observerList = new ArrayList<ActionListener>();

    public void load(String path, String name) throws FileNotFoundException, IOException, ClassNotFoundException
    {
        name = name.split(SUFFIX)[0];

        if (this.graphList.get(name) != null)
        {
            System.out.println("Arquivo ja carregado...");
            return;
        }

        Graph graph = Graph.load(path);

        this.graphList.put(name, graph);
        this.lastName = name;

        //notifico cada listener para informar que um novo grafo foi adicionado
        for (ActionListener el : observerList)
        {
            el.actionPerformed(null);
        }
    }

    public void addListener(ActionListener al)
    {
        this.observerList.add(al);
    }

    public Graph getGraph(String pathGraph)
    {
        return this.graphList.get(pathGraph).clone();
    }

    public String getLastIndex()
    {
        return this.lastName;
    }

    public Set<String> getGraphNames()
    {
        return this.graphList.keySet();
    }
}
