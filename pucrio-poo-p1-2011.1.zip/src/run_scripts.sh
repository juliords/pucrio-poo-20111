java pucriopoo20111.Main < script/testaTudo.script
java pucriopoo20111.Main < script/teste1.script
java pucriopoo20111.Main < script/teste2.script
java pucriopoo20111.Main < script/teste3.script
java pucriopoo20111.Main < script/teste4.script
java pucriopoo20111.Main < script/testeit.script
