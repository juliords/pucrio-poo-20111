/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pucriopoo20111;

/**
 *
 * @author juliords
 */
public class Highway implements graph.EdgeData{

    private String name;
    private double distance;

    public Highway(String name, double distance)
    {
        this.name = name;
        this.distance = distance;
    }

    public double getDistance()
    {
        return distance;
    }

    public void setDistance(double distance)
    {
        this.distance = distance;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public double getCost()
    {
        return this.distance;
    }

    public void print()
    {
        System.out.println("Highway: Name = "+getName()+"; Distante = "+getDistance());
    }

}
