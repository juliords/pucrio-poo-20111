/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pucriopoo20111;

import java.io.Serializable;

/**
 *
 * @author juliords
 */
public class City implements Serializable
{

    private String name;
    private int population;
    private double area;

    public City(String name, int population, double area)
    {
        this.name = name;
        this.population = population;
        this.area = area;
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    public double getArea()
    {
        return area;
    }

    public void setArea(double area)
    {
        this.area = area;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getPopulation()
    {
        return population;
    }

    public void setPopulation(int population)
    {
        this.population = population;
    }

    public void print()
    {
        System.out.println("City: Name = "+getName()+"; Population = "+getPopulation()+"; Area = "+getArea());
    }
}
