package graph.exception;

public class GraphException extends Exception
{
    @Override
    public String toString() { return "Problema encontrado ao realizar operação no Grafo.";}
}
