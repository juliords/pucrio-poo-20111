package graph.exception;

public class EdgeException extends GraphException
{
    @Override
    public String toString() { return "Problema encontrado ao realizar operação na aresta do Grafo.";}
}
