package graph.exception;

public class VerticeException extends GraphException
{
    @Override
    public String toString() { return "Problema encontrado ao realizar operação no vértice do Grafo.";}
}
